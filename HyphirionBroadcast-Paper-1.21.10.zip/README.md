# Hyphirion Broadcast — Paper 1.21.10

A simple server-wide announcement plugin for Hyphirion SMP.

## Features
- `/broadcast <message>` sends an announcement to every online player.
- Large red **BROADCAST** title with the message in white underneath.
- Also posts the message in chat.
- Permission: `hyphirion.broadcast.use` (operators by default).
- Java 21 / Paper 1.21.10.

## Build
1. Install Java 21 and Maven.
2. Open this project folder in a terminal.
3. Run:
   ```bash
   mvn package
   ```
4. Copy `target/hyphirion-broadcast-1.0.0.jar` into your server's `plugins` folder.
5. Restart the server.

## Example
`/broadcast Welcome to Hyphirion SMP!`

All online players see the red BROADCAST title and the message below it.
