package com.hyphirion.broadcast;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.title.Title;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.CommandExecutor;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.entity.Player;

import java.time.Duration;

public final class HyphirionBroadcast extends JavaPlugin implements CommandExecutor {

    @Override
    public void onEnable() {
        if (getCommand("broadcast") != null) {
            getCommand("broadcast").setExecutor(this);
        }
        getLogger().info("HyphirionBroadcast enabled!");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("hyphirion.broadcast.use")) {
            sender.sendMessage(Component.text("You don't have permission to use this command.")
                    .color(NamedTextColor.RED));
            return true;
        }

        if (args.length == 0) {
            sender.sendMessage(Component.text("Usage: /broadcast <message>")
                    .color(NamedTextColor.YELLOW));
            return true;
        }

        String message = String.join(" ", args).trim();
        if (message.isEmpty()) {
            sender.sendMessage(Component.text("Please enter a message.")
                    .color(NamedTextColor.RED));
            return true;
        }

        Component title = Component.text("BROADCAST")
                .color(NamedTextColor.RED)
                .decorate(TextDecoration.BOLD);

        Component subtitle = Component.text(message)
                .color(NamedTextColor.WHITE);

        Title.Times times = Title.Times.times(
                Duration.ofMillis(500),
                Duration.ofSeconds(5),
                Duration.ofMillis(1000)
        );

        for (Player player : getServer().getOnlinePlayers()) {
            player.showTitle(Title.title(title, subtitle, times));
            player.sendMessage(
                    Component.text("[Hyphirion] ", NamedTextColor.DARK_PURPLE)
                    .append(Component.text("Broadcast: ", NamedTextColor.RED))
                    .append(Component.text(message, NamedTextColor.WHITE))
            );
        }

        sender.sendMessage(Component.text("Broadcast sent!")
                .color(NamedTextColor.GREEN));
        getLogger().info("[Broadcast] " + sender.getName() + ": " + message);
        return true;
    }
}
